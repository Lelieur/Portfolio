export default function Thoughts() {
  return <div>Thoughts page</div>;
}
