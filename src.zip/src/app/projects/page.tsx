export default function Projects() {
  return <div>Projects page</div>;
}
