export default function Experiments() {
  return <div>Experiments page</div>;
}
