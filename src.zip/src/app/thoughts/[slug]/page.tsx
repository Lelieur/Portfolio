export default function ThougthPage() {
  return <div>Esto es una página de blog</div>;
}
