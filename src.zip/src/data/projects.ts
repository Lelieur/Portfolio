export const projects = [
  {
    title: "PickUp",
    description: "Cinephiles discussion platform",
    link: "/projects/pickup",
    year: "2025",
  },
  {
    title: "La Premiere",
    description: "Find your movie in your local cinema",
    link: "/projects/lapremiere",
    year: "2024",
  },
];
