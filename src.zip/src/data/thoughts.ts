export const thoughts = [
  {
    title: "The Future of Web Development",
    link: "/thoughts/the-future-of-web-development",
    year: "2025",
  },
];
