export const thoughts = [
  {
    title: 'The Future of Web Development',
    description: '',
    link: '/thoughts/the-future-of-web-development',
    year: '2025',
    slug: 'future-web-development',
  },
];
