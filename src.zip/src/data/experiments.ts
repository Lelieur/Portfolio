export const experiments = [
  {
    title: 'AI-Powered Movie Recommendation System',
    description: '',
    link: '/experiments/ai-movie-recommender',
    year: '2024',
    slug: 'ai-powered-movie-recommendation-system',
  },
  {
    title: 'Movie Review Sentiment Analysis',
    description: '',
    link: '/experiments/movie-review-sentiment-analysis',
    year: '2024',
    slug: 'movie-review-sentiment-analysis',
  },
];
