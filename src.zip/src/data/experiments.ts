export const experiments = [
  {
    title: "AI-Powered Movie Recommendation System",
    link: "/experiments/ai-movie-recommender",
    year: "2024",
  },
  {
    title: "Movie Review Sentiment Analysis",
    link: "/experiments/movie-review-sentiment-analysis",
    year: "2024",
  },
];
