export type MediumPost = {
  title: string;
  slug: string;
  link: string;
  content: string;
  date: string;
  image: string;
};
